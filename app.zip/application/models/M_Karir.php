<?php  
defined('BASEPATH') or exit('No direct script access allowed');

Class M_Karir extends CI_Model
{
    function tampil_data($id){
        $result = [];
        $where = ['id'=>$id];
        $this->db->select('*');
        $this->db->from('loker');
        $this->db->where($where);
        $data = $this->db->get()->row_array();
        // $query = $this->db->get('loker');
        if(!empty($data)){
            $result = [
                "id" => $data['id'],
                "divisi" => $data['divisi'],
                "nama_perusahaan" => $data['nama_perusahaan'],
                "alamat" => $data['alamat'],
                "date_created" => $data['date_created'],
                "syarat" => $data['syarat'],
                "gambar" => $data['gambar'],
            ];
        }
        return $result;
	}

    function getsDataUsers($email){
        $result = [];
        $where = ['email'=>$email];
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where($where);
        $data = $this->db->get()->row_array();
        if(!empty($data)){
            $result = [
                // "id" => $data['id'],
                "email" => $data['email'],
                "role_id" => $data['role_id'],
            ];
        }
        return $result;
	}

    function getsData($id){
        $result = [];
        $where = ['id'=>$id];
        $this->db->select('*');
        $this->db->from('loker');
        $this->db->where($where);
        $data = $this->db->get()->row_array();
        if(!empty($data)){
            $result = [
                "id" => $data['id'],
                "nama_perusahaan" => $data['nama_perusahaan'],
                "alamat" => $data['alamat'],
                "divisi" => $data['divisi'],
                "syarat" => $data['syarat'],
                "gambar" => $data['gambar'],
            ];
        }
        return $result;
	}

    // function search($keyword)
    // {
    //     if(!$keyword){
    //         return null;
    //     }
    //     $this->db->like('title', $keyword);
    //     $this->db->or_like('content', $keyword);
    //     $query = $this->db->get($this->_table);
    //     return $query->result();
    // }
}